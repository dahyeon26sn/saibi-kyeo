/*
 * 사이비켜 — Firebase 설정
 *
 * Firebase 콘솔 → 프로젝트 설정 → 내 앱(웹)에 나오는 firebaseConfig 값을
 * 아래 null 자리에 그대로 붙여 넣으세요.
 *
 * 이 값은 웹페이지에 공개되는 "주소" 같은 정보라 GitHub에 올려도 괜찮아요.
 * 데이터는 Firestore 보안 규칙(firestore.rules)이 지켜 줍니다.
 *
 * null 그대로 두면 이 기기에만 저장하는 데모 모드로 동작해요.
 *
 * 예시)
 * window.FIREBASE_CONFIG = {
 *   apiKey: "AIza...",
 *   authDomain: "saibi-kyeo.firebaseapp.com",
 *   projectId: "saibi-kyeo",
 *   storageBucket: "saibi-kyeo.appspot.com",
 *   messagingSenderId: "1234567890",
 *   appId: "1:1234567890:web:abcdef"
 * };
 */
window.FIREBASE_CONFIG = null;
